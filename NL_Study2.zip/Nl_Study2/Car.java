
public class Car {
	String Name ;
	int Speed ;
	int Location =0;
		
	
void Tostring() {
	this.toString();
}
void CarState(int time) {
	System.out.println(Location);
	Location = time*Speed;
	System.out.println(Location);
}
}
