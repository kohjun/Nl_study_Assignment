
public class Test {
public static void main(String[] args) {
	Car a = new Car();
	Car b = new Car();
	a.Name = "BMW";
	a.Speed = 150 ;
	b.Name = "Benz";
	b.Speed = 145 ;
	a.Tostring();
	b.Tostring();
	a.CarState(500);
	b.CarState(600);
}
}
